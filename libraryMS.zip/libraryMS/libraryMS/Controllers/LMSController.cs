﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using libraryMS.Models;

namespace libraryMS.Controllers
{
    public class LMSController : Controller
    {
        private DataAccess dtAccess = new DataAccess();
        // GET: /LMS/

        public ActionResult LibraryMS()
        {
            return View();
        }

        
        /**
         * Retrieve the data based on the parameter.
         * 
         */
        public ActionResult GetData(string param)
        {
            
            if ("AllBook" == param)
            {
                return Json(dtAccess.GetAllBooks(), JsonRequestBehavior.AllowGet);
            }
            else if ("AvailableBook" == param)
            {
                return new EmptyResult();
            }
            else if ("BorrowedBook" == param)
            {
                return new EmptyResult();
            }
            else if ("Categogry" == param)
            {
                return new EmptyResult();
            }
            else if ("History" == param)
            {
                return new EmptyResult();
            }
            else
            {
                return new EmptyResult();
            }
        }

        /**
         * 
         */
       
        public string Borrow(string[] isbns)
        {
            if(isbns != null)
            {
                //DataManager.GetDefault().HandleBorrowBookRequest(isbns);
            }
            return "Blablabla";
        }

        public ActionResult Return(string[] isbns)
        {
            if(isbns != null)
            {
               // DataAccess.GetDefault().HandleReturnBookRequest(isbns);
            }
            return View();
        }
    }
}
