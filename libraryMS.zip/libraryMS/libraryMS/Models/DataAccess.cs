﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace libraryMS.Models
{
    /**
     * Data access point.
     * 
     * @author Junior
     */
    public class DataAccess : DbContext
    {

        private DbSet<Book> Books;

        public List<Book> GetAllBooks()
        {
            return Books.ToList();
        }

        public DbSet<Category> GetAllCategories()
        {
           //return DummyData.GetSampleCategories();
            return null;
        }

        public DbSet<HistoryItem> GetUserHistory()
        {
            //return DummyData.GetSampelHistory();
            return null;
        }

        public void HandleBorrowBookRequest(string[] isbns)
        {
            isbns[0] = "";
        }

        public void HandleReturnBookRequest(string[] isbns)
        {

        }
    }
}