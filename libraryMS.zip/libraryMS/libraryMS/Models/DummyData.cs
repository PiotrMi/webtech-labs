﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace libraryMS.Models
{
    /**
     * A set of dummy data.
     * Just for testing.
     * 
     * @author Junior
     */
    public class DummyData
    {
        /*
        public static List<Book> GetSampleBooks()
        {
            List<Book> list = new List<Book>();
            list.Add(ModelFactory.GetDefault().CreateBook("0-201-10331-1", "Jon Louis Bentley", "Addison-Wesley professional","Programming Pearls", ""));
            list.Add(ModelFactory.GetDefault().CreateBook("978-87-7681-501-1", "Simon Kendal", "Springer", "object Oriented Programming using Java", ""));
            list.Add(ModelFactory.GetDefault().CreateBook("1-111-1-11","Ollie Dabbous","Addison-wesley","The cookbook",""));
            return list;
        }

        public static List<Category> GetSampleCategories()
        {
            List<Category> list = new List<Category>();
            list.Add(ModelFactory.GetDefault().CreateCategory("Computer science",10));
            list.Add(ModelFactory.GetDefault().CreateCategory("Cooking",25));
            list.Add(ModelFactory.GetDefault().CreateCategory("Sport",2));
            return list;
        }

        public static List<HistoryItem> GetSampelHistory()
        {
            List<HistoryItem> list = new List<HistoryItem>();
            list.Add(ModelFactory.GetDefault().CreateBorrowHistoryItem("21.12.2013","object Oriented Programming using Java","Simon Kendal","978-87-7681-501-1"));
            list.Add(ModelFactory.GetDefault().CreateReturnHistoryItem("10.06.2014", "object Oriented Programming using Java", "Simon Kendal", "978-87-7681-501-1"));
            return list;
        }
         */
    }
          
}