﻿CREATE TABLE [dbo].[Table]
(
	[Id] INT NOT NULL PRIMARY KEY, 
    [emailAddress] VARCHAR(50) NOT NULL, 
    [password] VARCHAR(50) NOT NULL
)
